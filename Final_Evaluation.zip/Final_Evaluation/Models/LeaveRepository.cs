﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Evaluation.Models
{
    public class LeaveRepository : ILeaveRepository
    {
        private readonly AppDbContext _appDbContext;
        public LeaveRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Leave> AllCategories => _appDbContext.Leaves;
    }
}
