﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Evaluation.Models
{
    public class EmployeeDetailRepository : IEmployeeDetailRepository
    {
        private readonly AppDbContext _appDbContext;
        public EmployeeDetailRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

    }
}
