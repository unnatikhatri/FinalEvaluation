﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Evaluation.Models
{
    public class AppDbContext : DbContext

    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }  
        public DbSet<EmployeeDetail> Employees { get; set; }

        public DbSet<Leave> Leaves { get; set; }

        public DbSet<EmployeeLeaveMapping> LeaveMappings { get; set; }
    }
}
