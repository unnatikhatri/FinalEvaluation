﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Evaluation.Models
{
    public class EmployeeLeaveMapping
    {
        public int Id { get; set; }
        public int EmpId { get; set; }
        public int LeaveId { get; set; }
        public int LeaveStartDate { get; set; }
        public int LeaveEndDate { get; set; }
        public bool Status { get; set; }
    }
}
