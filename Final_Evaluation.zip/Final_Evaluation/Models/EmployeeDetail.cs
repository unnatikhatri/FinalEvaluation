﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Evaluation.Models
{
    public class EmployeeDetail
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int DoB { get; set; }
        public int DoJ { get; set; }
        public int Salary { get; set; }
        public string Email { get; set; }
    }
}
