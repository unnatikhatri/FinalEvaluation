﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Evaluation.Models
{
    public class LeaveDetail
    {
        public string EmpName { get; set; }
        public int LeaveStart { get; set; }
        public int LeaveEnd { get; set; }
        public int LeaveBalance { get; set; }
        public string LeaveType { get; set; }
        public int NoOfDays { get; set; }
        public bool Status { get; set; }
        public bool Action {get; set; }
    }
}
