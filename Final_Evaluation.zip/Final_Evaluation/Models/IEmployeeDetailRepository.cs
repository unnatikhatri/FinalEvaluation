﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Evaluation.Models
{
    public class IEmployeeDetailRepository
    {
        IEnumerable<EmployeeDetail> AllEmployees { get; }

    }
    
}
